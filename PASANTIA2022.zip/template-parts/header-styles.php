<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
<style> .u-header {
  background-image: none;
  min-height: 99px;
}
.u-header .u-image-1 {
  width: 99px;
  height: 99px;
  margin: 0 auto 0 0;
}
.u-header .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
.u-header .u-social-icons-1 {
  white-space: nowrap;
  height: 47px;
  min-height: 16px;
  width: 160px;
  min-width: 68px;
  margin: -77px calc(((100% - 1140px) / 2) + -22px) 0 auto;
}
.u-header .u-icon-1 {
  color: rgb(59, 89, 152) !important;
}
.u-header .u-icon-2 {
  color: rgb(85, 172, 238) !important;
}
.u-header .u-icon-3 {
  color: rgb(197, 54, 164) !important;
}
.u-header .u-menu-1 {
  margin: -37px calc(((100% - 1140px) / 2) + 179px) 32px auto;
}
.u-header .u-nav-1 {
  font-weight: 500;
  font-size: 1rem;
  text-transform: uppercase;
  letter-spacing: normal;
}
.u-block-e144-28 {
  font-size: 1rem;
}
.u-header .u-nav-2 {
  font-size: 1rem;
}
.u-block-e144-30 {
  font-size: 1rem;
}
@media (max-width: 1199px) {
  .u-header .u-social-icons-1 {
    width: 160px;
    margin-right: calc(((100% - 1140px) / 2) + 78px);
  }
  .u-header .u-menu-1 {
    margin-top: -37px;
    margin-right: auto;
    margin-left: calc(((100% - 1140px) / 2) + 428px);
  }
}
@media (max-width: 991px) {
  .u-header .u-social-icons-1 {
    margin-right: calc(((100% - 1140px) / 2) + 188px);
  }
}
@media (max-width: 767px) {
  .u-header .u-image-1 {
    margin-left: calc(((100% - 1140px) / 2) + 439px);
  }
  .u-header .u-social-icons-1 {
    margin-right: auto;
    margin-left: calc(((100% - 1140px) / 2) + 490px);
  }
}</style>
